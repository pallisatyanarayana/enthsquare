function kitchen()
{
    document.getElementById("rsbtn1").innerHTML="4-Piece Set Bamboo Table Matt";
    document.getElementById("rsbtn2").innerHTML="Expresso Coffe Maker";
    document.getElementById("rsbtn3").innerHTML="12 Qt Pressure Cooker";
    document.getElementById("rsbtn4").innerHTML="Wooden Hexagonal Coasters";
}

function shoes()
{
    document.getElementById("rsbtn1").innerHTML="Puma Trainers x3";
    document.getElementById("rsbtn2").innerHTML="Sketchers ProWalkers";
    document.getElementById("rsbtn3").innerHTML="Reebok Classic 1990";
    document.getElementById("rsbtn4").innerHTML="Nike Air Max Elite";

}


function home()
{
    document.getElementById("rsbtn1").innerHTML="4*6 Photo Frame";
    document.getElementById("rsbtn2").innerHTML="Shower Curtain";
    document.getElementById("rsbtn3").innerHTML="Accent Table Lamp";
    document.getElementById("rsbtn4").innerHTML="100% Cotton Towels";
}

function eletronics()
{
    document.getElementById("rsbtn1").innerHTML="Cannon x930 DSLR Camera";
    document.getElementById("rsbtn2").innerHTML="Apple Iphone 8";
    document.getElementById("rsbtn3").innerHTML="Bose QC 300 Headphones";
    document.getElementById("rsbtn4").innerHTML="Sony Super Bass Earbuds";
}